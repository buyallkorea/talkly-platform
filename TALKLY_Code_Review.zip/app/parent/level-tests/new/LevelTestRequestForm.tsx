"use client";

import {
  FormEvent,
  useMemo,
  useState,
} from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase-browser";

type Child = {
  id: number;
  name: string;
  grade: string | null;
  school_name: string | null;
  birth_date?: string | null;
  learning_goal?: string | null;
  student_user_id: string | null;
  linked_student_user_id: string | null;
};

type Props = {
  currentUserId: string;
  parentUserId: string;
  userRole: "parent" | "student";
  children: Child[];
};

type StudentMode =
  | "existing"
  | "direct";

export default function LevelTestRequestForm({
  currentUserId,
  parentUserId,
  userRole,
  children,
}: Props) {
  const router = useRouter();
  const isStudent = userRole === "student";

  const [studentMode, setStudentMode] =
    useState<StudentMode>(
      children.length > 0
        ? "existing"
        : "direct"
    );

  const [childId, setChildId] =
    useState(
      children.length > 0
        ? String(children[0].id)
        : ""
    );

  const [
    studentName,
    setStudentName,
  ] = useState(
    children.length > 0
      ? children[0].name
      : ""
  );

  const [
    birthDate,
    setBirthDate,
  ] = useState(
    children.length > 0
      ? children[0].birth_date || ""
      : ""
  );

  const [age, setAge] =
    useState("");

  const [grade, setGrade] =
    useState(
      children.length > 0
        ? normalizeGrade(
            children[0].grade
          )
        : ""
    );

  const [
    schoolName,
    setSchoolName,
  ] = useState(
    children.length > 0
      ? children[0].school_name || ""
      : ""
  );

  const [
    learningHistory,
    setLearningHistory,
  ] = useState("");

  const [
    learningGoal,
    setLearningGoal,
  ] = useState(
    children.length > 0
      ? children[0].learning_goal || ""
      : ""
  );

  const [
    targetGroup,
    setTargetGroup,
  ] = useState(
    children.length > 0
      ? getTargetGroupFromGrade(
          children[0].grade
        )
      : "elementary"
  );

  const [loading, setLoading] =
    useState(false);

  const [
    errorMessage,
    setErrorMessage,
  ] = useState("");

  const [
    successMessage,
    setSuccessMessage,
  ] = useState("");

  const selectedChild =
    useMemo(() => {
      return (
        children.find(
          (child) =>
            String(child.id) ===
            childId
        ) ?? null
      );
    }, [childId, children]);

  function applyChild(
    child: Child
  ) {
    setStudentName(
      child.name
    );

    setBirthDate(
      child.birth_date || ""
    );

    setGrade(
      normalizeGrade(
        child.grade
      )
    );

    setSchoolName(
      child.school_name || ""
    );

    setLearningGoal(
      child.learning_goal || ""
    );

    setTargetGroup(
      getTargetGroupFromGrade(
        child.grade
      )
    );

    if (child.birth_date) {
      setAge(
        calculateAge(
          child.birth_date
        ).toString()
      );
    } else {
      setAge("");
    }
  }

  function handleModeChange(
    mode: StudentMode
  ) {
    setStudentMode(mode);
    setErrorMessage("");
    setSuccessMessage("");

    if (
      mode === "existing" &&
      selectedChild
    ) {
      applyChild(
        selectedChild
      );
    }

    if (mode === "direct") {
      setChildId("");
      setStudentName("");
      setBirthDate("");
      setAge("");
      setGrade("");
      setSchoolName("");
      setLearningHistory("");
      setLearningGoal("");
      setTargetGroup(
        "early_kids"
      );
    }
  }

  function handleChildChange(
    value: string
  ) {
    setChildId(value);
    setErrorMessage("");
    setSuccessMessage("");

    const child =
      children.find(
        (item) =>
          String(item.id) ===
          value
      );

    if (child) {
      applyChild(child);
    }
  }

  function handleBirthDateChange(
    value: string
  ) {
    setBirthDate(value);
    setSuccessMessage("");

    if (value) {
      setAge(
        calculateAge(
          value
        ).toString()
      );
    } else {
      setAge("");
    }
  }

  async function handleSubmit(
    event: FormEvent<HTMLFormElement>
  ) {
    event.preventDefault();

    setErrorMessage("");
    setSuccessMessage("");

    if (!studentName.trim()) {
      setErrorMessage(
        "학생 이름을 입력해주세요."
      );
      return;
    }

    if (!grade.trim()) {
      setErrorMessage(
        "학년을 입력해주세요."
      );
      return;
    }

    if (
      !birthDate &&
      !age.trim()
    ) {
      setErrorMessage(
        "학생 생년월일 또는 나이를 입력해주세요."
      );
      return;
    }

    if (age.trim()) {
      const parsedAge =
        Number(age);

      if (
        !Number.isInteger(
          parsedAge
        ) ||
        parsedAge < 3 ||
        parsedAge > 100
      ) {
        setErrorMessage(
          "학생 나이를 올바르게 입력해주세요."
        );
        return;
      }
    }

    setLoading(true);

    try {
      const response = await fetch(
        "/api/level-tests/request",
        {
          method: "POST",
          headers: {
            "Content-Type":
              "application/json",
          },
          body: JSON.stringify({
            studentMode,
            childId:
              studentMode === "existing" &&
              childId
                ? Number(childId)
                : null,
            studentName:
              studentName.trim(),
            birthDate:
              birthDate || null,
            age: age.trim()
              ? Number(age)
              : null,
            grade: grade.trim(),
            schoolName:
              schoolName.trim() || null,
            learningHistory:
              learningHistory.trim() ||
              null,
            learningGoal:
              learningGoal.trim() || null,
            targetGroup,
          }),
        }
      );

      const result = (await response.json()) as {
        success?: boolean;
        levelTestId?: number;
        existing?: boolean;
        role?: "parent" | "student";
        error?: string;
      };

      if (
        !response.ok ||
        !result.levelTestId
      ) {
        throw new Error(
          result.error ||
            "레벨테스트 신청에 실패했습니다."
        );
      }

      setSuccessMessage(
        result.existing
          ? "진행 중인 AI 레벨테스트로 이동합니다."
          : "AI 레벨테스트 신청이 완료되었습니다."
      );

      router.push(
        result.role === "student"
          ? `/parent/level-tests/${result.levelTestId}?studentMode=1`
          : `/parent/level-tests/${result.levelTestId}`
      );
    } catch (error) {
      console.error(
        "LEVEL TEST REQUEST ERROR:",
        error
      );

      setErrorMessage(
        error instanceof Error
          ? error.message
          : "레벨테스트 신청 중 알 수 없는 오류가 발생했습니다."
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <section
      style={{
        marginTop: "24px",
        padding: "26px",
        border:
          "1px solid #e4e7ec",
        borderRadius: "16px",
        background: "#ffffff",
      }}
    >
      <div>
        <h2
          style={{
            margin: 0,
            color: "#101828",
            fontSize: "20px",
            letterSpacing:
              "-0.02em",
          }}
        >
          레벨테스트 신청
        </h2>

        <p
          style={{
            margin:
              "8px 0 0",
            color: "#667085",
            fontSize: "13px",
            lineHeight: 1.7,
          }}
        >
          {isStudent
            ? children.length > 0
              ? "현재 로그인한 학생 정보로 레벨테스트를 신청합니다."
              : "현재 로그인한 수강생 본인의 정보를 입력하여 레벨테스트를 신청합니다."
            : "등록된 자녀를 선택하거나 레벨테스트를 받을 학생 정보를 직접 입력해주세요."}
        </p>
      </div>

      {!isStudent && children.length > 0 && (
        <div
          style={{
            marginTop: "24px",
            display: "grid",
            gridTemplateColumns:
              "repeat(2, minmax(0, 1fr))",
            gap: "12px",
          }}
        >
          <ModeButton
            selected={
              studentMode ===
              "existing"
            }
            title="등록된 자녀 선택"
            description="이미 TALKLY에 등록한 자녀로 신청"
            onClick={() =>
              handleModeChange(
                "existing"
              )
            }
          />

          <ModeButton
            selected={
              studentMode ===
              "direct"
            }
            title="학생 정보 직접 입력"
            description="레벨테스트만 받을 학생 정보 입력"
            onClick={() =>
              handleModeChange(
                "direct"
              )
            }
          />
        </div>
      )}

      <form
        onSubmit={handleSubmit}
        style={{
          marginTop: "26px",
          display: "flex",
          flexDirection:
            "column",
          gap: "22px",
        }}
      >
        {!isStudent &&
          studentMode ===
            "existing" &&
          children.length >
            0 && (
            <div>
              <label
                htmlFor="childId"
                style={labelStyle}
              >
                등록된 자녀
              </label>

              <select
                id="childId"
                value={childId}
                onChange={(
                  event
                ) =>
                  handleChildChange(
                    event.target.value
                  )
                }
                disabled={
                  loading
                }
                style={fieldStyle}
              >
                {children.map(
                  (child) => (
                    <option
                      key={
                        child.id
                      }
                      value={
                        child.id
                      }
                    >
                      {child.name}
                      {child.grade
                        ? ` / ${child.grade}`
                        : ""}
                    </option>
                  )
                )}
              </select>
            </div>
          )}

        <div
          style={
            twoColumnStyle
          }
        >
          <div>
            <label
              htmlFor="studentName"
              style={labelStyle}
            >
              학생 이름
            </label>

            <input
              id="studentName"
              type="text"
              value={
                studentName
              }
              onChange={(
                event
              ) => {
                setStudentName(
                  event.target
                    .value
                );
                setSuccessMessage(
                  ""
                );
              }}
              disabled={
                loading ||
                studentMode ===
                  "existing"
              }
              style={fieldStyle}
            />
          </div>

          <div>
            <label
              htmlFor="grade"
              style={labelStyle}
            >
              학년
            </label>

            <select
              id="grade"
              value={grade}
              onChange={(
                event
              ) => {
                const nextGrade =
                  event.target.value;

                setGrade(nextGrade);
                setTargetGroup(
                  getTargetGroupFromGrade(
                    nextGrade
                  )
                );
                setSuccessMessage(
                  ""
                );
              }}
              disabled={
                loading ||
                (isStudent && studentMode === "existing")
              }
              style={fieldStyle}
            >
              <option value="">
                학년을 선택해주세요
              </option>
              <option value="7세 / 미취학">
                7세 / 미취학
              </option>
              <option value="초등 1학년">
                초등 1학년
              </option>
              <option value="초등 2학년">
                초등 2학년
              </option>
              <option value="초등 3학년">
                초등 3학년
              </option>
              <option value="초등 4학년">
                초등 4학년
              </option>
              <option value="초등 5학년">
                초등 5학년
              </option>
              <option value="초등 6학년">
                초등 6학년
              </option>
              <option value="중학교 1학년">
                중학교 1학년
              </option>
              <option value="중학교 2학년">
                중학교 2학년
              </option>
              <option value="중학교 3학년">
                중학교 3학년
              </option>
              <option value="고등학교 1학년">
                고등학교 1학년
              </option>
              <option value="고등학교 2학년">
                고등학교 2학년
              </option>
              <option value="고등학교 3학년">
                고등학교 3학년
              </option>
              <option value="대학생">
                대학생
              </option>
              <option value="성인">
                성인
              </option>
            </select>
          </div>
        </div>

        <div
          style={
            twoColumnStyle
          }
        >
          <div>
            <label
              htmlFor="birthDate"
              style={labelStyle}
            >
              생년월일
            </label>

            <input
              id="birthDate"
              type="date"
              value={birthDate}
              onChange={(
                event
              ) =>
                handleBirthDateChange(
                  event.target.value
                )
              }
              disabled={
                loading ||
                (isStudent && studentMode === "existing")
              }
              style={fieldStyle}
            />
          </div>

          <div>
            <label
              htmlFor="age"
              style={labelStyle}
            >
              나이
            </label>

            <input
              id="age"
              type="number"
              min="3"
              max="100"
              value={age}
              onChange={(
                event
              ) => {
                setAge(
                  event.target
                    .value
                );
                setSuccessMessage(
                  ""
                );
              }}
              placeholder="예: 10"
              disabled={
                loading ||
                (isStudent && studentMode === "existing")
              }
              style={fieldStyle}
            />
          </div>
        </div>

        <div>
          <label
            htmlFor="schoolName"
            style={labelStyle}
          >
            학교명
            <span
              style={{
                marginLeft:
                  "5px",
                color:
                  "#98a2b3",
                fontSize:
                  "11px",
                fontWeight:
                  500,
              }}
            >
              선택
            </span>
          </label>

          <input
            id="schoolName"
            type="text"
            value={
              schoolName
            }
            onChange={(
              event
            ) => {
              setSchoolName(
                event.target
                  .value
              );
              setSuccessMessage(
                ""
              );
            }}
            placeholder="예: TALKLY초등학교"
            disabled={
              loading ||
              isStudent
            }
            style={fieldStyle}
          />
        </div>

        <div>
          <label
            htmlFor="targetGroup"
            style={labelStyle}
          >
            레벨테스트 유형
          </label>

          <div
            id="targetGroup"
            style={{
              ...fieldStyle,
              display: "flex",
              alignItems: "center",
              background: "#f9fafb",
              fontWeight: 800,
            }}
          >
            {getTargetGroupLabel(
              targetGroup
            )}
          </div>

          <p
            style={{
              margin: "7px 0 0",
              color: "#667085",
              fontSize: "11px",
              lineHeight: 1.6,
            }}
          >
            선택한 학년을 기준으로 AI 레벨테스트 유형이 자동 설정됩니다.
          </p>
        </div>

        <div>
          <label
            htmlFor="learningHistory"
            style={labelStyle}
          >
            영어 학습경력
            <span
              style={{
                marginLeft:
                  "5px",
                color:
                  "#98a2b3",
                fontSize:
                  "11px",
                fontWeight:
                  500,
              }}
            >
              선택
            </span>
          </label>

          <textarea
            id="learningHistory"
            value={
              learningHistory
            }
            onChange={(
              event
            ) => {
              setLearningHistory(
                event.target
                  .value
              );
              setSuccessMessage(
                ""
              );
            }}
            rows={4}
            placeholder="예: 영어학원 2년, 화상영어 6개월"
            disabled={loading}
            style={textareaStyle}
          />
        </div>

        <div>
          <label
            htmlFor="learningGoal"
            style={labelStyle}
          >
            영어 학습 목표
            <span
              style={{
                marginLeft:
                  "5px",
                color:
                  "#98a2b3",
                fontSize:
                  "11px",
                fontWeight:
                  500,
              }}
            >
              선택
            </span>
          </label>

          <textarea
            id="learningGoal"
            value={
              learningGoal
            }
            onChange={(
              event
            ) => {
              setLearningGoal(
                event.target
                  .value
              );
              setSuccessMessage(
                ""
              );
            }}
            rows={4}
            placeholder="예: 회화 자신감 향상, 학교 영어 보완"
            disabled={loading}
            style={textareaStyle}
          />
        </div>

        <div
          style={{
            padding: "18px",
            border:
              "1px solid #dbe7ff",
            borderRadius:
              "12px",
            background:
              "#f5f8ff",
          }}
        >
          <div
            style={{
              color:
                "#2f6fed",
              fontSize:
                "12px",
              fontWeight:
                900,
            }}
          >
            레벨테스트 결과 안내
          </div>

          <p
            style={{
              margin:
                "7px 0 0",
              color:
                "#667085",
              fontSize:
                "11px",
              lineHeight: 1.8,
            }}
          >
            테스트 결과는 TALKLY의
            내부 레벨 판단과 수업
            상담을 위한 자료로
            활용합니다. 세부 점수 및
            내부 분석 결과는 별도로
            제공하지 않으며 추가
            확인이 필요한 경우
            보호자에게 전화 또는 SNS로
            원어민 화상 테스트를
            안내합니다.
          </p>
        </div>

        {errorMessage && (
          <div
            style={errorStyle}
          >
            {errorMessage}
          </div>
        )}

        {successMessage && (
          <div
            style={
              successStyle
            }
          >
            {successMessage}
          </div>
        )}

        <div
          style={{
            display:
              "flex",
            justifyContent:
              "flex-end",
          }}
        >
          <button
            type="submit"
            disabled={loading}
            style={{
              minHeight:
                "48px",
              padding:
                "0 24px",
              border:
                "none",
              borderRadius:
                "10px",

              background:
                loading
                  ? "#98a2b3"
                  : "#0A1F44",

              color:
                "#ffffff",

              fontFamily:
                "inherit",

              fontSize:
                "13px",
              fontWeight:
                900,

              cursor:
                loading
                  ? "default"
                  : "pointer",
            }}
          >
            {loading
              ? "신청 중..."
              : "AI 레벨테스트 신청"}
          </button>
        </div>
      </form>
    </section>
  );
}

function ModeButton({
  selected,
  title,
  description,
  onClick,
}: {
  selected: boolean;
  title: string;
  description: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        minHeight: "82px",
        padding: "16px",
        border: selected
          ? "2px solid #2f6fed"
          : "1px solid #d0d5dd",
        borderRadius: "12px",
        background: selected
          ? "#f5f8ff"
          : "#ffffff",
        color: "#344054",
        fontFamily: "inherit",
        textAlign: "left",
        cursor: "pointer",
      }}
    >
      <div
        style={{
          color: selected
            ? "#2f6fed"
            : "#101828",
          fontSize: "13px",
          fontWeight: 900,
        }}
      >
        {title}
      </div>

      <div
        style={{
          marginTop: "5px",
          color: "#667085",
          fontSize: "11px",
          lineHeight: 1.6,
        }}
      >
        {description}
      </div>
    </button>
  );
}

function normalizeGrade(
  grade: string | null
) {
  if (!grade) {
    return "";
  }

  const raw = grade.trim();
  const value = raw
    .toLowerCase()
    .replace(/\s+/g, "");

  if (
    value.includes("성인") ||
    value.includes("adult")
  ) {
    return "성인";
  }

  if (
    value.includes("대학") ||
    value.includes("university") ||
    value.includes("college")
  ) {
    return "대학생";
  }

  const highMatch =
    value.match(
      /(?:고등학교|고등|고|high)([123])/
    );

  if (highMatch) {
    return `고등학교 ${highMatch[1]}학년`;
  }

  const middleMatch =
    value.match(
      /(?:중학교|중등|중|middle)([123])/
    );

  if (middleMatch) {
    return `중학교 ${middleMatch[1]}학년`;
  }

  const elementaryMatch =
    value.match(
      /(?:초등학교|초등|초)([1-6])/
    );

  if (elementaryMatch) {
    return `초등 ${elementaryMatch[1]}학년`;
  }

  const gradeOnlyMatch =
    value.match(/^([1-6])(?:학년)?$/);

  if (gradeOnlyMatch) {
    return `초등 ${gradeOnlyMatch[1]}학년`;
  }

  if (
    value.includes("7세") ||
    value.includes("미취학") ||
    value.includes("유치") ||
    value.includes("kindergarten") ||
    value === "7"
  ) {
    return "7세 / 미취학";
  }

  return raw;
}

function getTargetGroupFromGrade(
  grade: string | null
) {
  const normalized =
    normalizeGrade(grade);

  if (
    normalized ===
      "7세 / 미취학" ||
    normalized ===
      "초등 1학년" ||
    normalized ===
      "초등 2학년"
  ) {
    return "early_kids";
  }

  if (
    normalized.startsWith(
      "초등 "
    )
  ) {
    return "elementary";
  }

  if (
    normalized.startsWith(
      "중학교 "
    ) ||
    normalized.startsWith(
      "고등학교 "
    )
  ) {
    return "secondary";
  }

  if (
    normalized === "대학생" ||
    normalized === "성인"
  ) {
    return "adult";
  }

  return "elementary";
}

function getTargetGroupLabel(
  targetGroup: string
) {
  if (targetGroup === "early_kids") {
    return "7세~초2 영어 레벨테스트";
  }

  if (targetGroup === "elementary") {
    return "초3~초6 영어 레벨테스트";
  }

  if (targetGroup === "secondary") {
    return "중·고등 영어 레벨테스트";
  }

  if (targetGroup === "adult") {
    return "대학생·성인 영어 레벨테스트";
  }

  return "영어 레벨테스트";
}

function calculateAge(
  birthDate: string
) {
  const today =
    new Date();

  const birth =
    new Date(
      `${birthDate}T00:00:00`
    );

  let age =
    today.getFullYear() -
    birth.getFullYear();

  const monthDifference =
    today.getMonth() -
    birth.getMonth();

  if (
    monthDifference < 0 ||
    (monthDifference === 0 &&
      today.getDate() <
        birth.getDate())
  ) {
    age -= 1;
  }

  return age;
}

const twoColumnStyle = {
  display: "grid",
  gridTemplateColumns:
    "repeat(2, minmax(0, 1fr))",
  gap: "14px",
};

const labelStyle = {
  display: "block",
  marginBottom: "8px",
  color: "#344054",
  fontSize: "13px",
  fontWeight: 800,
};

const fieldStyle = {
  width: "100%",
  minHeight: "46px",
  boxSizing:
    "border-box" as const,
  padding: "0 14px",
  border:
    "1px solid #d0d5dd",
  borderRadius: "9px",
  background: "#ffffff",
  color: "#101828",
  fontFamily: "inherit",
  fontSize: "14px",
  outline: "none",
};

const textareaStyle = {
  ...fieldStyle,
  minHeight: "110px",
  padding: "13px 14px",
  resize: "vertical" as const,
  lineHeight: 1.7,
};

const errorStyle = {
  padding: "14px 16px",
  border:
    "1px solid #fda29b",
  borderRadius: "10px",
  background: "#fffbfa",
  color: "#b42318",
  fontSize: "12px",
  fontWeight: 700,
  lineHeight: 1.6,
};

const successStyle = {
  padding: "14px 16px",
  border:
    "1px solid #abefc6",
  borderRadius: "10px",
  background: "#ecfdf3",
  color: "#027a48",
  fontSize: "12px",
  fontWeight: 800,
};